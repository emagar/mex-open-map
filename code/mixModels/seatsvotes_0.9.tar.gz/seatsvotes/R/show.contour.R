show.contour <-
function(fit) { 
    ## display contour plots of the distribution of vote log-ratios
    interval <- 21
    dat <- fit$dat
    size <- dat[,1]/10000
    dat <- dat[,-1]
    np <- ncol(dat)
    par(mar=c(3.7,3.7,0.5,0.5),tcl=-0.3,mgp=c(3,0.5,0))
    layout(matrix(c(1:((np-1)^2)),np-1,np-1))
    mu <- fit$mu
    sig <- fit$sig
    P <- fit$P
    R <- nrow(mu)
    if (is.null(R)) R <- 1
    y <- matrix(NA,nrow=nrow(dat),ncol=np-1)
    for (i in 2:ncol(dat)) {y[,(i-1)] <- log(dat[,i]/dat[,1])}    # use first party as reference for log-ratios
    y <- cbind(size,y)
    ifelse(length(fit)>0,pcol <- "gray50",pcol <- "black")
    for (lr.h in 1:(np-1)) {
        for (lr.v in 2:np) {
            z <- matrix(0,nrow=interval,ncol=interval)
            if ((lr.v-1) >= lr.h) {
                plot(y[,c(lr.h,lr.v)],xlim=c(floor(min(y[,lr.h])),ceiling(max(y[,lr.h]))),
                     ylim=c(floor(min(y[,lr.v])),ceiling(max(y[,lr.v]))),col=pcol,xlab="",ylab="")
                if (lr.h==1) {
                    mtext(side=1,text="district size in 10k",line=2,cex=1.2)
                } else {
                    mtext(side=1,text=paste("ln(",colnames(dat)[lr.h],"/",colnames(dat)[1],")",sep=""),line=2,cex=1.2)
                }
                mtext(side=2,text=paste("ln(",colnames(dat)[lr.v],"/",colnames(dat)[1],")",sep=""),line=2,cex=1.2)
                if (length(fit)>0) {
                for (ix in 1:interval) {
                    for (iy in 1:interval) {
                        xval <- (((ix-1)/(interval-1)) * (ceiling(max(y[,lr.h]))-floor(min(y[,lr.h])))) + floor(min(y[,lr.h]))
                        yval <- (((iy-1)/(interval-1)) * (ceiling(max(y[,lr.v]))-floor(min(y[,lr.v])))) + floor(min(y[,lr.v]))
                        for (r in 1:R) {
                            z[ix,iy] <- z[ix,iy] + P[r]*dmvnorm(c(xval,yval),mean=mu[r,c(lr.h,lr.v)],sigma=sig[c(lr.h,lr.v),c(lr.h,lr.v),r])
                        }
                    }
                }
                contour(x=seq(floor(min(y[,lr.h])),ceiling(max(y[,lr.h])),len=interval),y=seq(floor(min(y[,lr.v])),ceiling(max(y[,lr.v])),len=interval),z,
                    add=T,drawlabels=F,lwd=2,nlevels=7)
                }
            } else {
                plot(0,col="white",col.axis="white",col.lab="white",xaxt="n",yaxt="n",bty="n") # empty plot
            }
        }
    }
}
