sim.election <-
function(fit,dat) {
    vsim <- matrix(NA,nrow=nrow(dat),ncol=ncol(dat))
    pos <- 1
    for (f in 1:length(fit)) {
        pcol <- match(fit[[f]]$cols,names(dat))
        if (length(pcol)==2) {  # uncontested districts
            vsim[pos:(pos+fit[[f]]$N-1),pcol] <- cbind(rep(0,fit[[f]]$N),rep(1,fit[[f]]$N))
        } else {
            R <- length(fit[[f]]$P)
            draws <- matrix(NA,nrow=fit[[f]]$N,ncol=ncol(fit[[f]]$dat)-1)
            grp <- rmultinom(1,fit[[f]]$N,fit[[f]]$P)
            ins <- 1
            for (r in 1:R) {
                if (grp[r] > 0) {
                    draws[ins:sum(grp[1:r]),] <- rmvnorm(grp[r],mean=fit[[f]]$mu[r,],sigma=fit[[f]]$sig[,,r],method="chol")
                    ins <- ins+grp[r]
                }
            }
            voteshares <- exp(cbind(0,draws[,2:ncol(draws)]))/rowSums(exp(cbind(0,draws[,2:ncol(draws)])))
            vsim[pos:(pos+fit[[f]]$N-1),pcol] <- cbind(draws[,1],voteshares)
        }
        pos <- pos+fit[[f]]$N
    }
    vsim[(vsim[,1]<0),1] <- 0.0001
    return(vsim)
}
