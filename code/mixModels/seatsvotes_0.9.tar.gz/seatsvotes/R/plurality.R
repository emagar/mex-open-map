plurality <-
function(votes) {
    nr <- nrow(votes)
    nc <- ncol(votes)
    wm <- NULL
    for (i in 1:nr) { wm <- c(wm,which.max(votes[i,])) }
    seats <- NULL
    for (i in 1:nc) { seats <- c(seats,sum(wm==i)) }
    return(seats/nr)
}
