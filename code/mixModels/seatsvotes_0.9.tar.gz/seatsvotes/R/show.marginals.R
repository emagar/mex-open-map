show.marginals <-
function(fit,numdraws=10000) { 
    ## compare observed party vote histograms to fitted marginal distributions
    ## enter numdraws=0 if do not want to show estimated density functions
    dat <- reconstruct(fit)
    if (numdraws > 0) {     # if calculating smoothed density from model
        numdraws <- ceiling(numdraws/nrow(dat))*nrow(dat)
        vsim <- NULL
        for (i in 1:(numdraws/nrow(dat))) {
            vsim <- rbind(vsim,sim.election(fit,dat))
        }
    }
    np <- ncol(dat)
    par(mfrow=c(np,1),mar=c(4,3,0.5,0.5))
    hist(dat[,1]/10000,breaks=30,main="",ylab="",xlab="",freq=F,cex.axis=1.1,col="gray90")
    if (numdraws > 0) { lines(density(vsim[vsim[,1]>0,1],na.rm=T,adjust=0.7),lwd=2) }
    mtext(side=1,text="Votes Cast in 10,000s",line=2.5,cex=1.1)
    mtext(side=2,text="density",line=2,cex=0.8)
    for (i in 2:np) {
        hist(dat[,i],breaks=seq(0,1,0.02),xlab="",ylab="",main="",cex.axis=1.1,freq=F,col="gray90")
        mtext(side=1,text=paste(colnames(dat)[i]),line=2.5,cex=1.1)
        if (numdraws > 0) lines(density(vsim[,i],na.rm=T,from=0,to=1,adjust=0.6),lwd=2)
        mtext(side=2,text="density",line=2,cex=0.8)
    }
}
