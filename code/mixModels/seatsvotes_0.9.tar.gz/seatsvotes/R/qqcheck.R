qqcheck <-
function(fit,ptynum) {
    dat <- reconstruct(fit)
    dat[is.na(dat)] <- 0
    vsim <- sim.election(fit, dat)
    vsim[is.na(vsim)] <- 0
    qqplot(dat[,ptynum+1],vsim[,ptynum+1],xlab="Observed vote shares",ylab="Simulated vote shares",
            asp=1,xlim=c(0,1),ylim=c(0,1),main=names(dat)[ptynum+1])
    abline(0,1)
    invisible(NULL)
}
