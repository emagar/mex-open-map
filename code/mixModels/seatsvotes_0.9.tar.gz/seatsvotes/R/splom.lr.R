splom.lr <-
function(y,pnam,mu,sig,P,plot.ell) {
    # make scatterplot matrix of party votes in log-ratio scale
    np <- ncol(y)
    par(mar=c(3.7,3.7,0.5,0.5),tcl=-0.3,mgp=c(3,0.5,0))
    layout(matrix(c(1:((np-1)^2)),np-1,np-1))
    R <- nrow(mu)
    if (is.null(R)) { R <- 1 }
    for (hor in 1:(np-1)) {
    for (ver in 2:np) {
        if ((ver-1) >= hor) {
            plot(y[,c(hor,ver)],xlim=c(floor(min(y[,hor])),ceiling(max(y[,hor]))),
                 ylim=c(floor(min(y[,ver])),ceiling(max(y[,ver]))),col="gray50",xlab="",ylab="")
            if (hor==1) {
                mtext(side=1,text="district size in 10k",line=2,cex=1.2)
            } else {
                mtext(side=1,text=paste("ln(",pnam[hor],"/",pnam[1],")",sep=""),line=2,cex=1.2)
            }
            mtext(side=2,text=paste("ln(",pnam[ver],"/",pnam[1],")",sep=""),line=2,cex=1.2)
            if (plot.ell) {
                if (is.matrix(sig)) {
                    lines(ellipse(sig[c(hor,ver),c(hor,ver)],centre=matrix(mu[c(hor,ver)]),t=2),lwd=2)
                } else {
                    for (r in 1:R) {
                        lines(ellipse(sig[c(hor,ver),c(hor,ver),r],centre=mu[r,c(hor,ver)],t=2),lwd=2)
                    }
                    text(x=mu[,hor],y=mu[,ver],labels=round(P,2),font=2,cex=1.4)
                }
            }
        } else {
            plot(0,col="white",col.axis="white",col.lab="white",xaxt="n",yaxt="n",bty="n") # empty plot
        }
    }
    }
}
