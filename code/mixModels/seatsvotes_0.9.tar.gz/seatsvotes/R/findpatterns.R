findpatterns <-
function(dat) {
    dat <- as.data.frame(dat)
    gtz <- as.data.frame(dat[,2:ncol(dat)]>0)
    o <- do.call(order,gtz[names(gtz)])
    gtz <- gtz[o,]
    dat <- dat[o,]
    splitdat <- list()
    pat <- 1
    prev <- gtz[1,]
    splitdat[[pat]] <- dat[1,]
    for (i in 2:nrow(dat)) {
        if (!all(gtz[i,]==prev)) {  # if a new pattern
            pat <- pat+1
            splitdat[[pat]] <- dat[i,]
        } else {                    # if the same pattern
            splitdat[[pat]] <- rbind(splitdat[[pat]],dat[i,])
        }
        prev <- gtz[i,]
    }
    cat(pat,"patterns of contestation: \n")
    nm <- NULL
    for (i in 1:length(splitdat)) {
        splitdat[[i]] <- splitdat[[i]][,c(TRUE,colSums(splitdat[[i]][,-1])>0)]
        nm <- c(nm,paste(names(splitdat[[i]])[-1],collapse="-"))
        cat("[",i,"] ",nm[i],": ",nrow(splitdat[[i]]),"\n",sep="")
    }
    names(splitdat) <- nm
    invisible(splitdat)
}
