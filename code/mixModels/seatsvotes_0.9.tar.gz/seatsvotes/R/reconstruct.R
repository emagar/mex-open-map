reconstruct <-
function(fit) {
    dat <- fit[[1]]$dat
    if (length(fit) > 1) {
        for (i in 2:length(fit)) {
            dat <- rbind.fill(dat,fit[[i]]$dat)
        }
    }
    return(dat)
}
